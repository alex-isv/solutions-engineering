console.log('Ansible Playbook Cockpit Extension Loaded');
